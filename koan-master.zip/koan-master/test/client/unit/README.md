# Client side unit tests

All the client unit tests live side by side with the client side code. The test files are simply suffixed with .spec.js as per convention.

You can have a look at [/client/modules/profile/profile.component.spec.js](/client/modules/profile/profile.component.spec.js)